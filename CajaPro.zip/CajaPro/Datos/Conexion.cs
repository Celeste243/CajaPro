﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CajaPro.Datos
{
    public class Conexion
    {
        private SqlConnection conexion = new SqlConnection(
    @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=CajaPro;Integrated Security=True;TrustServerCertificate=True");

        public SqlConnection AbrirConexion()
        {
            if (conexion.State == System.Data.ConnectionState.Closed)
                conexion.Open();

            return conexion;
        }

        public SqlConnection CerrarConexion()
        {
            if (conexion.State == System.Data.ConnectionState.Open)
                conexion.Close();

            return conexion;
        }
    }
}