﻿using System.Data.SqlClient;
using CajaPro.Datos;
using CajaPro.Logica;
using CajaPro.Modelos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CajaPro
{
    public partial class FormProductos : Form
    {
        public FormProductos()
        {
            InitializeComponent();
        }

        private void FormProductos_Load(object sender, EventArgs e)
        {
            RefrescarTabla();
        }
       
        private void RefrescarTabla()
        {
            dgvProductos.Rows.Clear();
            MessageBox.Show("Cantidad de productos: " + SupermercadoEngine.Productos.Count);
            foreach (var prod in SupermercadoEngine.Productos)
            {
                string estado = prod.Activo ? "Disponible" : "Baja Lógica";
                dgvProductos.Rows.Add(prod.Id, prod.Nombre, prod.Precio.ToString("F2"), prod.Stock, estado);
            }
        }

        // ==========================================
        // REQUERIMIENTO: ALTA / MODIFICACIÓN DE PRODUCTO
        // ==========================================
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                Conexion cn = new Conexion();

                SqlConnection conexion = cn.AbrirConexion();

                // Obtener el próximo Id
                SqlCommand cmdId = new SqlCommand("SELECT ISNULL(MAX(IdProductos),0)+1 FROM Productos", conexion);
                int nuevoId = Convert.ToInt32(cmdId.ExecuteScalar());

                SqlCommand cmd = new SqlCommand(
                "INSERT INTO Productos (IdProductos, Codigo, Nombre, Categoria, Precio, Stock, Estado) VALUES (@Id,@Codigo,@Nombre,@Categoria,@Precio,@Stock,@Estado)",
                conexion);

                cmd.Parameters.AddWithValue("@Id", nuevoId);
                cmd.Parameters.AddWithValue("@Codigo", txtCodigo.Text);
                cmd.Parameters.AddWithValue("@Nombre", txtNombre.Text);
                cmd.Parameters.AddWithValue("@Categoria", textBox1.Text);
                cmd.Parameters.AddWithValue("@Precio", decimal.Parse(txtPrecio.Text));
                cmd.Parameters.AddWithValue("@Stock", (int)numericUpDown1.Value);
                cmd.Parameters.AddWithValue("@Estado", true);

                cmd.ExecuteNonQuery();

                cn.CerrarConexion();

                MessageBox.Show("Producto guardado correctamente.");

                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        // ==========================================
        // REQUERIMIENTO: BAJA LÓGICA (CON DEPENDENCIAS)
        // ==========================================
        private void btnBaja_Click(object sender, EventArgs e)
        {
            try
            {
                string codigo = txtCodigo.Text.Trim();
                var prod = SupermercadoEngine.Productos.FirstOrDefault(p => p.Id == codigo);

                if (prod == null)
                {
                    MessageBox.Show("Seleccione o escriba un código de producto válido.", "CajaPro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // VALIDACIÓN CLAVE DE EXAMEN: Verificar si ya se vendió antes de borrar
                bool yaSeVendio = SupermercadoEngine.HistorialVentas.Any(v => v.Items.Any(i => i.IdProducto == codigo));

                if (yaSeVendio)
                {
                    // Bloqueo lógico para no romper los tickets viejos de la caja
                    prod.Activo = false;
                    MessageBox.Show("El producto tiene historial de ventas. Se aplicó una BAJA LÓGICA (Deshabilitado de góndolas para no romper registros).", "CajaPro - Integridad", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    // Borrado físico directo porque nunca se usó
                    SupermercadoEngine.Productos.Remove(prod);
                    MessageBox.Show("Producto eliminado físicamente del sistema por no registrar ventas anteriores.", "CajaPro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                RefrescarTabla();
                LimpiarCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al procesar baja: {ex.Message}", "CajaPro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LimpiarCampos()
        {
            txtCodigo.Clear();
            txtNombre.Clear();
            txtPrecio.Clear();
            numericUpDown1.Value = 0;
            txtCodigo.Focus();
        }

        // Evento extra: Si el usuario hace clic en una fila de la tabla, carga los datos en los campos de arriba
        private void dgvProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvProductos.Rows[e.RowIndex];
                txtCodigo.Text = row.Cells[0].Value?.ToString();
                txtNombre.Text = row.Cells[1].Value?.ToString();
                txtPrecio.Text = row.Cells[2].Value?.ToString();
                if (int.TryParse(row.Cells[3].Value?.ToString(), out int stockVal))
                    numericUpDown1.Value = stockVal;
            }
        }
    }
}